"use client";

import { useState } from "react";

export default function Home() {
  const [exercise, setExercise] = useState("");
  const [duration, setDuration] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!exercise || !duration) {
      alert("Please fill in all fields");
      return;
    }

    setIsLoading(true);
    setResult(null);

    try {
      // Call our API endpoint to get AI-powered calorie calculation
      const response = await fetch('/api/calculate-calories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          exercise: exercise.trim(),
          duration: parseInt(duration)
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to calculate calories');
      }

      if (data.success) {
        setResult(data.aiResponse);
      } else {
        throw new Error('Unexpected response format');
      }
    } catch (error) {
      console.error("Error:", error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to calculate calories';
      setResult(`❌ Error: ${errorMessage}\n\nPlease check that your OpenAI API key is properly configured in the .env.local file.`);
    } finally {
      setIsLoading(false);
    }
  };

  const clearForm = () => {
    setExercise("");
    setDuration("");
    setResult(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            🏃‍♂️ Fitness Tracker
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Track your workouts and get AI-powered calorie burn estimates. 
            Tell us what exercise you did and for how long!
          </p>
        </div>

        {/* Main Form Card */}
        <div className="max-w-md mx-auto">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Exercise Input */}
              <div>
                <label htmlFor="exercise" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  What exercise did you do?
                </label>
                <input
                  type="text"
                  id="exercise"
                  value={exercise}
                  onChange={(e) => setExercise(e.target.value)}
                  placeholder="e.g., Running, Swimming, Weightlifting..."
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-colors"
                  disabled={isLoading}
                />
              </div>

              {/* Duration Input */}
              <div>
                <label htmlFor="duration" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  How long? (minutes)
                </label>
                <input
                  type="number"
                  id="duration"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  placeholder="30"
                  min="1"
                  max="480"
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-colors"
                  disabled={isLoading}
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Calculating...
                  </>
                ) : (
                  "Calculate Calories Burned 🔥"
                )}
              </button>
            </form>

            {/* Result Display */}
            {result && (
              <div className="mt-8 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                  </div>
                                     <div className="ml-3">
                     <div className="text-sm font-medium text-green-800 dark:text-green-200 whitespace-pre-line">
                       {result}
                     </div>
                     <button
                       onClick={clearForm}
                       className="mt-4 text-sm text-green-600 dark:text-green-400 hover:text-green-500 font-medium"
                     >
                       Track another workout →
                     </button>
                   </div>
                </div>
              </div>
            )}
          </div>

                     {/* Features Preview */}
           <div className="mt-8 text-center">
             <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
               ✨ Powered by AI - Get personalized calorie estimates and fitness tips!
             </p>
             <div className="flex justify-center space-x-6 text-xs text-gray-400">
               <span>🤖 AI Analysis</span>
               <span>🔥 Calorie Tracking</span>
               <span>💡 Fitness Tips</span>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
}
