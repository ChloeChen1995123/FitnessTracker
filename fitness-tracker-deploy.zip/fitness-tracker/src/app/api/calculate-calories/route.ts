import { OpenAI } from 'openai';
import { NextRequest, NextResponse } from 'next/server';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(request: NextRequest) {
  try {
    // Parse the request body
    const { exercise, duration } = await request.json();

    // Validate input
    if (!exercise || !duration) {
      return NextResponse.json(
        { error: 'Exercise and duration are required' },
        { status: 400 }
      );
    }

    // Check if OpenAI API key is configured - if not, use demo mode
    const isDemo = !process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === 'your_openai_api_key_here';
    
    if (isDemo) {
      // Demo mode - provide realistic calorie estimates without OpenAI
      const demoResponses = {
        'running': {
          caloriesPerMinute: 10,
          tips: "Great cardio exercise! Running builds endurance and burns calories efficiently. Try to maintain a steady pace and focus on your breathing."
        },
        'walking': {
          caloriesPerMinute: 4,
          tips: "Walking is excellent low-impact exercise! Perfect for daily activity and recovery. Aim for 10,000 steps per day for optimal health."
        },
        'swimming': {
          caloriesPerMinute: 12,
          tips: "Swimming is a full-body workout! Excellent for building strength and endurance while being easy on your joints. Try different strokes for variety."
        },
        'cycling': {
          caloriesPerMinute: 8,
          tips: "Cycling is great for leg strength and cardio! Adjust your resistance or terrain to increase intensity. Don't forget to stay hydrated!"
        },
        'weightlifting': {
          caloriesPerMinute: 6,
          tips: "Strength training builds muscle and boosts metabolism! Focus on proper form over heavy weights. Rest between sets for best results."
        },
        'yoga': {
          caloriesPerMinute: 3,
          tips: "Yoga improves flexibility, balance, and mindfulness! Regular practice can reduce stress and improve overall well-being. Listen to your body and don't force poses."
        }
      };

      // Find the best match for the exercise
      const exerciseLower = exercise.toLowerCase();
      let matchedExercise = null;
      
      for (const [key, value] of Object.entries(demoResponses)) {
        if (exerciseLower.includes(key) || key.includes(exerciseLower)) {
          matchedExercise = value;
          break;
        }
      }

      // Default to moderate exercise if no match found
      if (!matchedExercise) {
        matchedExercise = {
          caloriesPerMinute: 7,
          tips: "Great workout choice! Remember to stay hydrated and listen to your body. Consistency is key to achieving your fitness goals."
        };
      }

      const estimatedCalories = Math.round(matchedExercise.caloriesPerMinute * duration);
      const demoResponse = `🔥 **Estimated Calories Burned: ${estimatedCalories} calories**

**Exercise:** ${exercise} for ${duration} minutes

**Calculation:** Based on an average adult (70kg/154lbs), you burned approximately ${matchedExercise.caloriesPerMinute} calories per minute.

**Fitness Tips:** ${matchedExercise.tips}

---
*⚡ Demo Mode Active - For more detailed AI analysis, add your OpenAI API key to .env.local*`;

      return NextResponse.json({
        success: true,
        exercise,
        duration,
        aiResponse: demoResponse,
        timestamp: new Date().toISOString(),
        isDemo: true
      });
    }

    // Create the prompt for OpenAI
    const prompt = `You are a fitness and nutrition expert. Calculate the approximate calories burned for the following workout:

Exercise: ${exercise}
Duration: ${duration} minutes

Please provide:
1. Estimated calories burned (give a specific number)
2. A brief explanation of the calculation factors
3. Any relevant fitness tips for this exercise

Assume an average adult (70kg/154lbs) for the calculation. Be specific and helpful.

Format your response in a clear, conversational way that's easy to understand.`;

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a knowledgeable fitness expert who provides accurate calorie burn estimates and helpful fitness advice."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 300,
      temperature: 0.7,
    });

    const response = completion.choices[0]?.message?.content;

    if (!response) {
      throw new Error('No response from OpenAI');
    }

    // Return the AI response
    return NextResponse.json({
      success: true,
      exercise,
      duration,
      aiResponse: response,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error calling OpenAI API:', error);
    
    // Handle different types of errors
    if (error instanceof Error) {
      return NextResponse.json(
        { 
          error: 'Failed to calculate calories',
          message: error.message
        },
        { status: 500 }
      );
    }

    return NextResponse.json(
      { 
        error: 'An unexpected error occurred',
        message: 'Please try again later'
      },
      { status: 500 }
    );
  }
} 